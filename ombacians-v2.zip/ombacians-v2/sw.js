const CACHE = "ombacians-v2";
const FILES = ["./","./index.html","./style.css","./config.js","./app.js","./manifest.json"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))); self.skipWaiting(); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))); self.clients.claim(); });
self.addEventListener("fetch", e => { if(e.request.method !== "GET") return; e.respondWith(caches.match(e.request).then(c => c || fetch(e.request))); });